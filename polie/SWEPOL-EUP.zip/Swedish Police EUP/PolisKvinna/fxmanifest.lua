-- Generated with AltTool

fx_version 'bodacious'
game { 'gta5' }

files {
  'mp_f_freemode_01_mp_f_polis.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_polis.meta'